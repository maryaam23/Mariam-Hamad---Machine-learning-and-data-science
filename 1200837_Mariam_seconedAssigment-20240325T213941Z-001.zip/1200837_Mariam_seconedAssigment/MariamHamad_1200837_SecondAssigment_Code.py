#Mariam Hamad - 1200837
#Second Assigment 22/12/2023
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from mpl_toolkits.mplot3d import Axes3D
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


print("\nModel Selection and Hyper-parameters Tunning\n")
print("------------------------------------\n")
print("             FIRST TASK      \n")
print("------------------------------------\n")
#read the data from file
Data_file = pd.read_csv('data_reg.csv', sep='\t')
# Split the data from file to training, validation, and testing sets
Training_Set = Data_file.iloc[:120]
Validation_Set = Data_file.iloc[120:160]
Test_Set = Data_file.iloc[160:]
print("Train Data:")
print(Training_Set)
print("\nValidation Data:")
print(Validation_Set.shape)
print(Validation_Set)
print("\nTest Data:")
print(Test_Set.shape)
print(Test_Set)

# Plot the examples from the three sets in a 3D scatter plot
First_Figure = plt.figure(figsize=(10, 10))
First_Figure_Details= First_Figure.add_subplot(111, projection='3d')
First_Figure_Details.set_title("1- 3D Scatter Plot For sets", fontsize=14, fontweight='bold', fontstyle='oblique', color='navy')
First_Figure_Details.text2D(0.01, 0.95, "Mariam Hamad - 1200837", transform=First_Figure_Details.transAxes, fontsize=12,fontstyle='oblique', fontweight='bold', color='#0047AB')

First_Figure_Details.set_xlabel("X1 ", color='blue', fontsize=12, fontweight='bold', labelpad=20)
First_Figure_Details.set_ylabel("X2 ", color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
First_Figure_Details.set_zlabel("Y ", color='#FFD700', fontsize=12, fontweight='bold', labelpad=20)


First_Figure_Details.scatter(Training_Set['x1'], Training_Set['x2'], Training_Set['y'], color='darkviolet', label='Training Set')

First_Figure_Details.scatter(Validation_Set['x1'], Validation_Set['x2'], Validation_Set['y'], color='blue', label='Validation Set')

First_Figure_Details.scatter(Test_Set['x1'], Test_Set['x2'], Test_Set['y'], color='yellow', label='Testing Set')

print("Training Set:")
print("x1:")
print(Training_Set['x1'].head())
print("x2:")
print(Training_Set['x2'].head())
print("y:")
print(Training_Set['y'].head())
First_Figure_Details.legend()

#-----------------------------------------------------------------

print("------------------------------------\n")
print("             SECOND TASK      \n")
print("------------------------------------\n")


Validation_Error = []
Models = []
Poly_Degree = range(1, 11)

# Get training and validation data
X_training = Training_Set[['x1', 'x2']].values
Y_training = Training_Set['y'].values
X_Validation = Validation_Set[['x1', 'x2']].values
Y_Validation= Validation_Set['y'].values

# Apply polynomial regression for degrees 1 to 10
for Degree in Poly_Degree:
    # Polynomial features
    Polynomial_F = PolynomialFeatures(Degree)
    X_train_poly = Polynomial_F.fit_transform(X_training)
    X_val_poly = Polynomial_F.transform(X_Validation)

    Model= LinearRegression()       # Train the model
    Model.fit(X_train_poly, Y_training)

    y_val_pred = Model.predict(X_val_poly)       # Predict on the validation set

    mse = mean_squared_error(Y_Validation, y_val_pred)      # Calculate the validation error (MSE)
    Validation_Error.append(mse)

    Models.append(Model)        # Store the trained model

# Plot the validation error vs polynomial degree curve
plt.figure(figsize=(10, 6))
plt.plot(Poly_Degree, Validation_Error, marker='o', color='gold')
plt.title('Validation Error vs. Polynomial Degree', fontsize=14, fontweight='bold', fontstyle='oblique', color='navy')
plt.text(0.01, 0.95, "Mariam Hamad - 1200837", transform=plt.gca().transAxes, fontsize=12, fontstyle='oblique', fontweight='bold', color='#0047AB')
plt.xlabel('Polynomial Degree', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('Mean Squared Error', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.xticks(Poly_Degree)
plt.grid(True)

# Find the degree with the lowest validation error
best_degree_index = np.argmin(Validation_Error)
best_degree = Poly_Degree[best_degree_index]
best_model = Models[best_degree_index]
print(f"The best polynomial degree is {best_degree} with a validation MSE of {Validation_Error[best_degree_index]:.4f}\n")


# Plot the surface for the best degree  of the learned function on the training examples
Third_Figure = plt.figure(figsize=(10, 10))
Third_Figure_Details = Third_Figure.add_subplot(111, projection='3d')
x1 = np.linspace(X_training[:, 0].min(), X_training[:, 0].max(), 100) # Create 100 linearly spaced points in X_training between the minimum and maximum of the first feature (column 0).
x2 = np.linspace(X_training[:, 1].min(), X_training[:, 1].max(), 100) # Create 100 linearly spaced points in X_training between the minimum and maximum of the first feature (column 1).
x1, x2 = np.meshgrid(x1, x2)
X_poly = PolynomialFeatures(best_degree).fit_transform(np.hstack((x1.reshape(-1, 1), x2.reshape(-1, 1))))
y_plot = best_model.predict(X_poly)

Third_Figure_Details.plot_surface(x1, x2, y_plot.reshape(x1.shape), alpha=0.3, color='blue')    # Plot the surface
Third_Figure_Details.scatter(X_training[:, 0], X_training[:, 1], Y_training, color='purple', label='Training Set')
Third_Figure_Details.text2D(0.01, 0.95, "Mariam Hamad - 1200837", transform=plt.gca().transAxes, fontsize=12, fontstyle='oblique', fontweight='bold', color='#0047AB')
Third_Figure_Details.set_xlabel('X1', color='blue', fontsize=12, fontweight='bold', labelpad=20)
Third_Figure_Details.set_ylabel('X2',color='darkviolet', fontsize=12, fontweight='bold', labelpad=20 )
Third_Figure_Details.set_zlabel('Y', color='#FFD700', fontsize=12, fontweight='bold', labelpad=20)
Third_Figure_Details.set_title(f'Polynomial Regression (Degree {best_degree}) Surface with Training Data', fontsize=14, fontweight='bold', fontstyle='oblique', color='navy')
Third_Figure_Details.legend()



# Generate meshgrid for plotting
x1_range = np.linspace(X_training[:, 0].min(), X_training[:, 0].max(), 100)
x2_range = np.linspace(X_training[:, 1].min(), X_training[:, 1].max(), 100)
x1, x2 = np.meshgrid(x1_range, x2_range)
# Now plot all figures in a single plot for visual comparison
fig_all_degrees, axs = plt.subplots(2, 5, figsize=(20, 10), subplot_kw={'projection': '3d'})
fig_all_degrees.suptitle('Polynomial Regression Surfaces for Degrees 1 to 10', fontsize=20)

with PdfPages('polynomial_degrees.pdf') as pdf:
 for i, Degree in enumerate(Poly_Degree):

    Figure_Pdf = plt.figure(figsize=(10, 8))
    ax = Figure_Pdf.add_subplot(111, projection='3d')
    Polynomial_F = PolynomialFeatures(Degree)   # Generate poly features for meshgrid
    X_poly = Polynomial_F.fit_transform(np.hstack((x1.reshape(-1, 1), x2.reshape(-1, 1))))
    y_plot = Models[i].predict(X_poly) # Predict on the generated meshgrid
    ax.plot_surface(x1, x2, y_plot.reshape(x1.shape), alpha=0.3, color='blue') # Plot the surface

    # Plot the training examples
    ax.scatter(X_training[:, 0], X_training[:, 1], Y_training, color='purple', label='Training Data')
    ax.text2D(0.01, 0.95, "Mariam Hamad - 1200837", transform=plt.gca().transAxes, fontsize=12, fontstyle='oblique', fontweight='bold', color='#0047AB')
    # Set labels and title
    ax.set_title(f'Polynomial (Degree = {Degree}) Surface with Training Data', fontsize=14, fontweight='bold', fontstyle='oblique', color='navy')
    ax.set_xlabel('X1', color='blue', fontsize=12, fontweight='bold', labelpad=20)
    ax.set_ylabel('X2',color='darkviolet', fontsize=12, fontweight='bold', labelpad=20 )
    ax.set_zlabel('Y', color='#FFD700', fontsize=12, fontweight='bold', labelpad=20)
    pdf.savefig(Figure_Pdf)
    plt.close(Figure_Pdf)

#Plot all figure for all degree in same page.
for i, Degree in enumerate(range(1, 11)):
    ax = axs[i // 5, i % 5]
    Polynomial_F = PolynomialFeatures(Degree) # Generate polynomial features
    X_poly = Polynomial_F.fit_transform(np.hstack((x1.reshape(-1, 1), x2.reshape(-1, 1))))
    y_plot = Models[i].predict(X_poly).reshape(x1.shape)    # Predict on the generated meshgrid
    ax.plot_surface(x1, x2, y_plot, alpha=0.3, color='blue')  # Plot the surface
    ax.scatter(X_training[:, 0], X_training[:, 1], Y_training, color='purple', label='Training Data')
    ax.set_title(f'Degree {Degree}', fontsize=10) # put title for each plot.
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.tight_layout()


#----------------------------------------------------------

print("------------------------------------\n")
print("             THIRD TASK      \n")
print("------------------------------------\n")

poly_degree = 8
Alpha_Parameter_Values = [0.001, 0.005, 0.01, 0.1, 10]
poly = PolynomialFeatures(degree=poly_degree) # Applying polynomial features transformation
X_train_poly = poly.fit_transform(X_training)
X_val_poly = poly.transform(X_Validation)

# Function to apply ridge regression and calculate MSE
def apply_ridge_and_calculate_mse(alpha, X_train_poly, y_train, X_val_poly, y_val):
    model = Ridge(alpha=alpha)
    model.fit(X_train_poly, y_train)
    y_val_pred = model.predict(X_val_poly)
    MSE = mean_squared_error(y_val, y_val_pred)
    return MSE

Validation_Errors_Ridge = []  # Apply ridge regression for each alpha and calculate MSE for validation data
for alpha in Alpha_Parameter_Values:
    MSE = apply_ridge_and_calculate_mse(alpha, X_train_poly, Y_training, X_val_poly, Y_Validation)
    Validation_Errors_Ridge.append(MSE)

# Plotting the MSE on validation vs the regularization parameter
plt.figure(figsize=(12, 8))
plt.plot(Alpha_Parameter_Values, Validation_Errors_Ridge, marker='o', color='gold')
plt.text(0.01, 0.95, "Mariam Hamad - 1200837", transform=plt.gca().transAxes, fontsize=12, fontstyle='oblique', fontweight='bold', color='#0047AB')
plt.xlabel('Regularization Parameter (alpha)', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('Validation MSE', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.title('Validation MSE vs Regularization Parameter (Ridge Regression)',
          fontsize=14, fontweight='bold', fontstyle='oblique', color='navy', pad=20)
# Find the alpha with minimum validation error
Best_Alpha_Index = np.argmin(Validation_Errors_Ridge)
Best_Alpha = Alpha_Parameter_Values[Best_Alpha_Index]
Best_MSE = Validation_Errors_Ridge[Best_Alpha_Index]
# Highlight the best alpha value and its corresponding MSE
plt.scatter([Best_Alpha], [Best_MSE], color='red', zorder=5)

# Annotate the best alpha directly on the plot
plt.annotate(f'Best alpha: {Best_Alpha:.4f}\nMin MSE: {Best_MSE:.4f}',
             xy=(Best_Alpha, Best_MSE), xycoords='data',
             xytext=(40, -30), textcoords='offset points',
             arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"),
             bbox=dict(boxstyle="round,pad=0.3", edgecolor='red', facecolor='white'),
             fontsize=10, color='red')
plt.xscale('log')
plt.grid(True)


# Find the alpha with minimum validation error
Best_Alpha = Alpha_Parameter_Values[np.argmin(Validation_Errors_Ridge)]
Best_Alpha, Validation_Errors_Ridge[np.argmin(Validation_Errors_Ridge)]
print(f"The best regularization parameter (alpha) for ridge regression is {Best_Alpha} with a minimum MSE of {Validation_Errors_Ridge[np.argmin(Validation_Errors_Ridge)]:.4f} on the validation set.\n\n")

#--------------------------------------------------------------


print("\n Logistic Regression\n")
print("------------------------------------\n")
print("             FIRST TASK      \n")
print("------------------------------------\n")
# Load the training and testing data from files
Train_Cls_Data = pd.read_csv('train_cls.csv', sep='\t')
Test_Cls_Data = pd.read_csv('test_cls.csv', sep='\t')
Train_Cls_Data['class'] = Train_Cls_Data['class'].map({'C1': 1, 'C2': 0})  # Convert class labels from C1, C2 to 0, 1

# Separate features and labels for the training set
X1_train = Train_Cls_Data['x1']
X2_train = Train_Cls_Data['x2']
Class_train = Train_Cls_Data['class']
Test_Cls_Data['class'] = Test_Cls_Data['class'].map({'C1': 1, 'C2': 0})   # Convert class labels from C1, C2 to 0, 1 for the test set

# Separate features and labels for the test set
X1_test = Test_Cls_Data['x1']
X2_test = Test_Cls_Data['x2']
Class_test = Test_Cls_Data['class']

Logistic_Reg = LogisticRegression()    # Create a logistic regression model

# DataFrame for training and testing data.
X_train = pd.DataFrame({'x1': X1_train, 'x2': X2_train})
X_test = pd.DataFrame({'x1': X1_test, 'x2': X2_test})

Logistic_Reg.fit(X_train, Class_train)      # Train the model

# Predictions
Class_train_pred = Logistic_Reg.predict(X_train)
Class_test_pred = Logistic_Reg.predict(X_test)

# Calculate Accuracies
Train_Accuracy = accuracy_score(Class_train, Class_train_pred)
Test_Accuracy= accuracy_score(Class_test, Class_test_pred)

print(f"Training Accuracy: {Train_Accuracy}")
print(f"Testing Accuracy: {Test_Accuracy}")

plt.figure(figsize=(10, 6))
class_labels = {0: 'Class C2 (yellow)', 1: 'Class C1 (blue)'}   # Define labels for the classes with correct colors

# Scatter plot for training data with labels
for class_value, class_name in class_labels.items():
    # Choose color based on class
    color = 'gold' if class_value == 0 else 'blue'
    plt.scatter(X_train.loc[Class_train == class_value, 'x1'],
                X_train.loc[Class_train == class_value, 'x2'],
                c=color, edgecolor='white', marker='*', s=200, label=class_name)

# Decision boundary
x_values = np.array([X_train['x1'].min(), X_train['x1'].max()])
y_values = -(Logistic_Reg.intercept_ + Logistic_Reg.coef_[0][0] * x_values) / Logistic_Reg.coef_[0][1]
plt.plot(x_values, y_values, color='purple', label="Decision Boundary")
plt.text(0.68, 0.95, "Mariam Hamad - 1200837", transform=plt.gca().transAxes, fontsize=12, fontstyle='oblique', fontweight='bold', color='#0047AB')
plt.xlabel('X1', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('X2', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.legend()
plt.title('Linear Decision Boundary on Training Data', fontsize=14, fontweight='bold', fontstyle='oblique', color='navy', pad=20)

#-------------------------------------------------------------------------------
print("------------------------------------\n")
print("             SECOND TASK      \n")
print("------------------------------------\n")

# Create polynomial features
Poly_F = PolynomialFeatures(degree=2, include_bias=False)
log_regG = LogisticRegression()  # Create a logistic regression model

# Create a pipeline that first transforms the data to polynomial features, then applies logistic regression
pipeline = Pipeline([('polynomial_features', Poly_F), ('logistic_regression', log_regG)])
pipeline.fit(X_train, Class_train)   # Train the model using the pipeline

# Predictions for training and test sets
y_train_predD = pipeline.predict(X_train)
y_test_predD = pipeline.predict(X_test)

# Calculate accuracies
Train_AccuracyY = accuracy_score(Class_train, y_train_predD)
Test_AccuracyY = accuracy_score(Class_test, y_test_predD)
print(f"Training Accuracy: {Train_AccuracyY}")
print(f"Testing Accuracy: {Test_AccuracyY}")

# Plotting decision boundary
x_min, x_max = X_train['x1'].min() - 1, X_train['x1'].max() + 1
y_min, y_max = X_train['x2'].min() - 1, X_train['x2'].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.01),
                     np.arange(y_min, y_max, 0.01))

# Plot decision boundary and margins
Z = pipeline.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
plt.figure(figsize=(10, 8))
class_labels = {0: 'Class C2 (yellow)', 1: 'Class C1 (blue)'}
plt.contour(xx, yy, Z, levels=[0.5], colors='darkorchid', vmin=0, vmax=1)
plt.scatter(X_train.loc[Class_train == 1, 'x1'], X_train.loc[Class_train == 1, 'x2'],
            color='blue', marker='*', s=150, label='Class C1 (blue stars)')
plt.scatter(X_train.loc[Class_train == 0, 'x1'], X_train.loc[Class_train == 0, 'x2'],
            color='gold', marker='*', s=150, label='Class C2 (yellow stars)')

plt.xlabel('X1', color='gold', fontsize=14, fontweight='bold', labelpad=20)
plt.ylabel('X2', color='blue', fontsize=14, fontweight='bold', labelpad=20)
plt.title('Logistic Regression with Quadratic Decision Boundary', fontsize=16, fontweight='bold', color='navy', pad=20)

plt.text(0.01, 0.95, "Mariam Hamad - 1200837", transform=plt.gca().transAxes,
         fontsize=12, fontstyle='oblique', fontweight='bold', color='#0047AB')
handles, labels = plt.gca().get_legend_handles_labels()
handles.append(plt.Line2D([], [], color='darkorchid', label='Quadratic Boundary'))
plt.legend(handles=handles)
# Show the plot
plt.show()