#Mariam Hamad - 1200837 - First Assignment

# Import necessary libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


print("----------------------------------------")
print("                 FIRST PART")
print("----------------------------------------\n")

# 1. Read the dataset
df = pd.read_csv('cars.csv')
print("File opened successfully.")
print("How Many Features And Examples Does It Have?")
print("\nThe result:\n")

# Display number of features and examples
Features_Number = df.shape[1] #determined number of columns (features) - second element in the tuple
Examples_Number = df.shape[0] #determined number of rows (examples) - first element in the tuple
print(f"The Number Of Features: {Features_Number}")
print(f"The Number Of Examples: {Examples_Number}")
print("\n- - - NOTE - - -")
print("The Number Of Features Equal The Number Of Column In The File")
print("The Number Of Examples equal The Number Of The Rows In The File (except the first row because have the titles)")

# 2. Check for missing values
print("\n----------------------------------------")
print("                 SECOND PART")
print("----------------------------------------\n")
missing_values = df.isnull().sum()  #COUNT THE NUMBER OF MISSING VALUES IN EACH FEATURES
print("Missing values :\n")
print("The Features    | The numbers of missing values for each feature\n")
print(missing_values)


print("\n----------------------------------------")
print("                 THIRD PART")
print("----------------------------------------\n")
# Impute missing values with mode for all missing value for each feature
for column in df.columns:
    df[column].fillna(df[column].mode()[0], inplace=True)
# Display missing values after imputation
missing_values_after = df.isnull().sum()
print("\nMissing values after imputation:")
print("The Features    | The numbers of missing values for each feature\n")
print(missing_values_after)

# 4. Box plot for fuel economy by country
print("\n----------------------------------------")
print("                 FOURTH PART")
print("----------------------------------------\n")
sns.set(style="whitegrid")
plt.figure(figsize=(12, 8))
custom_palette = sns.color_palette(['#FFFF00', '#007FFF', '#FF007F'])
boxplot = sns.boxplot(x='origin', y='mpg', data=df, hue='origin', palette=custom_palette, showfliers=False, linewidth=2)
plt.title('Fuel Economy for Each Country\n\n', fontsize=18, weight='bold')
plt.xlabel('Country', fontsize=16, weight='bold', color='purple', labelpad=15)
plt.ylabel('Miles Per Gallon (mpg)', fontsize=16, weight='bold', color='purple', labelpad=15)
boxplot.set_xticks(boxplot.get_xticks())
boxplot.set_yticks(boxplot.get_yticks())
boxplot.set_xticklabels(boxplot.get_xticklabels(), color='black', fontsize=14)
boxplot.set_yticklabels(boxplot.get_yticklabels(), color='black', fontsize=14)
plt.text(1.0, 1.03, 'MARIAM HAMAD - 1200837', transform=plt.gca().transAxes, fontsize=12, ha='right', va='bottom', color='purple')

median_mpg_by_country = df.groupby('origin')['mpg'].median()
print("Median Miles Per Gallon (mpg) by Country From The Plot We Have:")
print(median_mpg_by_country)
# Determine the country with the highest median 'mpg'
best_country = median_mpg_by_country.idxmax()

# Print the result
print(f"The country that produces cars with better fuel economy is: {best_country}")


print("\n----------------------------------------")
print("                 FIFTH & SIXTH PART")
print("----------------------------------------\n")
fig=plt.figure(figsize=(15, 5))
def add_annotations(feature, ax):
    mean_value = df[feature].mean()
    median_value = df[feature].median()
    mode_value = df[feature].mode()[0]

    ax.text(0.5, 0.9, f'Mean: {mean_value:.2f}', transform=ax.transAxes, fontsize=10, ha='center', va='center',
            color='black')
    ax.text(0.5, 0.8, f'Median: {median_value}', transform=ax.transAxes, fontsize=10, ha='center', va='center',
            color='black')
    ax.text(0.5, 0.7, f'Mode: {mode_value}', transform=ax.transAxes, fontsize=10, ha='center', va='center',
            color='black')


# Histogram for 'acceleration'
plt.subplot(1, 3, 1)
sns.histplot(df['acceleration'], kde=True, color='skyblue')
plt.title('Acceleration Distribution')
add_annotations('acceleration', plt.gca())

# Histogram for 'horsepower'
plt.subplot(1, 3, 2)
sns.histplot(df['horsepower'], kde=True, color='salmon')
plt.title('Horsepower Distribution')
add_annotations('horsepower', plt.gca())

# Histogram for 'mpg'
plt.subplot(1, 3, 3)
sns.histplot(df['mpg'], kde=True, color='lightgreen')
plt.title('MPG Distribution')
add_annotations('mpg', plt.gca())
# Add your name to the upper-right corner of the figure
fig.text(0.95, 0.95, 'MARIAM HAMAD - 1200837', fontsize=12, ha='right', va='top', color='purple')


# 6. Quantitative measures (mean, median, mode, variance, and skewness)
for feature in ['acceleration', 'horsepower', 'mpg']:
    mean_value = df[feature].mean()
    median_value = df[feature].median()
    mode_value = df[feature].mode()[0]  # In case there are multiple modes
    variance_value = df[feature].var()
    skewness_value = df[feature].skew()

    print(
        f"{feature} - Mean: {mean_value:.2f}, Median: {median_value}, Mode: {mode_value}, Variance: {variance_value:.2f}, Skewness: {skewness_value:.2f}")


print("\n----------------------------------------")
print("        SEVENTH AND EIGHTH PART")
print("----------------------------------------\n")

# Scatter plot
plt.figure(figsize=(10, 6))
sns.scatterplot(x='horsepower', y='mpg', data=df, marker='o', color='blue', label='Data Points (Scatter)')
plt.title('Scatter Plot with Linear Regression Line\nof Horsepower vs. MPG')
plt.xlabel('Horsepower')
plt.ylabel('Miles Per Gallon (MPG)')
correlation_coefficient = df['horsepower'].corr(df['mpg'])

if correlation_coefficient > 0:
    interpretation = "There is a positive correlation."
elif correlation_coefficient < 0:
    interpretation = "There is a negative correlation."
else:
    interpretation = "There is no correlation."

print(f'Correlation Coefficient between Horsepower and MPG: {correlation_coefficient}')
print(f'Interpretation: {interpretation}')

# Add a column of ones for the intercept
X = np.column_stack((np.ones_like(df['horsepower']), df['horsepower']))
Y = df['mpg'].values

# Compute the closed-form solution
beta = np.linalg.inv(X.T @ X) @ X.T @ Y

# Plot the learned line
x_values = np.linspace(df['horsepower'].min(), df['horsepower'].max(), 100)
y_values = beta[0] + beta[1] * x_values
plt.plot(x_values, y_values, color='red', linestyle='-', linewidth=2, label='Linear Regression Line')

# Set plot labels and legend
plt.legend()

print("\n----------------------------------------")
print("                 NINTH PART")
print("----------------------------------------\n")

# Scatter plot
plt.figure(figsize=(10, 6))
sns.scatterplot(x='horsepower', y='mpg', data=df, marker='o', color='blue', label='Data Points (Scatter)')
plt.title('Scatter Plot with Quadratic Regression\nof Horsepower vs. MPG')
plt.xlabel('Horsepower')
plt.ylabel('Miles Per Gallon (MPG)')

# Add a column of ones and the quadratic term for the intercept and quadratic regression
X_quad = np.column_stack((np.ones_like(df['horsepower']), df['horsepower'], df['horsepower'] ** 2))
Y_quad = df['mpg'].values

# Compute the closed-form solution for quadratic regression
beta_quad = np.linalg.inv(X_quad.T @ X_quad) @ X_quad.T @ Y_quad

# Plot the learned quadratic curve
x_values_quad = np.linspace(df['horsepower'].min(), df['horsepower'].max(), 100)
y_values_quad = beta_quad[0] + beta_quad[1] * x_values_quad + beta_quad[2] * x_values_quad**2
plt.plot(x_values_quad, y_values_quad, color='red', linestyle='-', linewidth=2, label='Quadratic Regression Curve')

# Set plot labels and legend
plt.legend()


print("\n----------------------------------------")
print("                PART 10 - LINEAR REGRESSION (GRADIENT DESCENT)")
print("----------------------------------------\n")
plt.figure(figsize=(10, 6))
sns.scatterplot(x='horsepower', y='mpg', data=df)
plt.title('Scatter Plot of Horsepower vs. MPG')
plt.xlabel('Horsepower')
plt.ylabel('Miles Per Gallon (MPG)')

# Add a column of ones for the intercept
X = np.column_stack((np.ones_like(df['horsepower']), df['horsepower']))
Y = df['mpg'].values

learning_rate = 0.000025
num_iterations = 1000000
beta_gradient_descent = np.zeros(X.shape[1])

for iteration in range(num_iterations):
    predictions = X @ beta_gradient_descent
    errors = predictions - Y
    gradient = 2 * X.T @ errors / len(Y)
    beta_gradient_descent -= learning_rate * gradient

# Plot the learned line from gradient descent
x_values_gradient_descent = np.linspace(df['horsepower'].min(), df['horsepower'].max(), 100)
y_values_gradient_descent = beta_gradient_descent[0] + beta_gradient_descent[1] * x_values_gradient_descent
plt.plot(x_values_gradient_descent, y_values_gradient_descent, color='red', label='Linear Regression Line (Gradient Descent)')

# Set plot labels and title
plt.xlabel('Horsepower')
plt.ylabel('MPG')
plt.legend()
plt.show()