# Leena Affouri-1200335
# Mariam Hamad- 1200837
#Assigment 3 Machine Learning
#***********************************************************
import pandas as pd
import sns as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, r2_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, r2_score
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error

print("------------------------------------\n")
print("             FIRST TASK      \n")
print("------------------------------------\n")

# Read The Data
data = pd.read_csv('boston.csv', sep='\t')

# X will be all columns except 'MEDV', and y will be just the 'MEDV' column.
X = data.drop('MEDV', axis=1)
y = data['MEDV']

fig, axs = plt.subplots(ncols=7, nrows=2, figsize=(20, 10))
axs = axs.flatten()  # Flatten the array for easy iteration
colors = sns.color_palette("viridis", n_colors=len(data.columns))  # Use the 'viridis' color palette

for i, (k, v) in enumerate(data.items()):
    sns.histplot(v, bins=15, kde=False, color=colors[i], ax=axs[i]).set_title(k)
    axs[i].set_xlabel('')  # Remove x-labels to have a cleaner look
    axs[i].set_ylabel('')  # Remove y-labels to have a cleaner look

plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=5.0)  # Adjust the layout to provide more space

plt.figure(figsize=(14, 10))
correlation_matrix = data.corr().abs()

heatmap = sns.heatmap(correlation_matrix, annot=True, cmap='magma', fmt=".2f", linewidths=.5)
plt.title('Correlation Heatmap of Boston Housing Dataset')

fig, axs = plt.subplots(ncols=7, nrows=2, figsize=(20, 10))
axs = axs.flatten()  # Flatten the array for easy iteration
# Using a more distinct color palette (e.g., 'Set2') for better clarity
colors = sns.color_palette("Set2", n_colors=len(data.columns))

for i, (k, v) in enumerate(data.items()):
    sns.boxplot(y=k, data=data, ax=axs[i], color=colors[i])
    axs[i].set_title(k, fontsize=14)  # Set title with a larger font size for clarity

plt.tight_layout(pad=2.0, w_pad=3.0, h_pad=3.0)  # Increase the space for more clarity

for k, v in data.items():
    q1 = v.quantile(0.25)
    q3 = v.quantile(0.75)
    irq = q3 - q1
    v_col = v[(v <= q1 - 1.5 * irq) | (v >= q3 + 1.5 * irq)]
    perc = np.shape(v_col)[0] * 100.0 / np.shape(data)[0]
    print("Column %s outliers = %.2f%%" % (k, perc))

print("\n------------------------------------\n")
print("             SECOND TASK      \n")
print("------------------------------------\n")

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)  # Using 20% for testing


# Function to compute RMSE for different values of k
def RMSE_K_COMPUTEVALUES(X_train, y_train, X_test, y_test):
    k_values = list(range(1, 51))
    rmse_scores = []

    for k in k_values:
        knn = KNeighborsRegressor(n_neighbors=k)
        knn.fit(X_train, y_train)
        pred = knn.predict(X_test)
        rmse = np.sqrt(mean_squared_error(y_test, pred))
        rmse_scores.append(rmse)

    return k_values, rmse_scores


k_vals, rmse_scores = RMSE_K_COMPUTEVALUES(X_train, y_train, X_test, y_test)
# Find the best k value
min_rmse = min(rmse_scores)
best_k = k_vals[rmse_scores.index(min_rmse)]

# Plotting the results
plt.figure(figsize=(16, 10))
plt.text(0.01, 0.95, "Mariam Hamad - 1200837 \nLeena Affouri - 1200335", transform=plt.gcf().transFigure, fontsize=12,
         fontstyle='oblique', fontweight='bold', color='#0047AB')
plt.plot(k_vals, rmse_scores, marker='o', color='gold')
plt.title('K-Nearest Neighbors Regression: RMSE vs K Value', fontsize=14, fontweight='bold', fontstyle='oblique',
          color='navy')
plt.xlabel('k value', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('RMSE', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.xticks(k_vals)
plt.grid(True)
# Highlight the best k value
plt.scatter(best_k, min_rmse, color='purple', label='Best k (k={}) with RMSE={:.2f}'.format(best_k, min_rmse))
plt.legend()


# Function to train and evaluate KNN regressor
def KNN_REGRESSION(k, X_train, y_train, X_test, y_test):
    # Create KNN Regressor
    knn = KNeighborsRegressor(n_neighbors=k)

    # Train the model using the training sets
    knn.fit(X_train, y_train)

    # Predict the response for test dataset
    y_pred = knn.predict(X_test)

    # Calculate and return RMSE and predictions
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    return y_pred, rmse


# Evaluate the model for k=1 and k=3 on the test set
y_pred_k1, rmse_k1 = KNN_REGRESSION(1, X_train, y_train, X_test, y_test)
y_pred_k3, rmse_k3 = KNN_REGRESSION(3, X_train, y_train, X_test, y_test)

# Now, let's plot the actual vs predicted values for both k=1 and k=3.
plt.figure(figsize=(14, 7))

# Plot for k=1
plt.subplot(1, 2, 1)
plt.scatter(y_test, y_pred_k1, color='blue')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=3)
plt.title('Actual vs Predicted for k=1', fontsize=14, fontweight='bold', fontstyle='oblique', color='navy')
plt.xlabel('Actual', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('Predicted', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)

# Plot for k=3
plt.subplot(1, 2, 2)
plt.scatter(y_test, y_pred_k3, color='gold')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=3)
plt.title('Actual vs Predicted for k=3', fontsize=14, fontweight='bold', fontstyle='oblique', color='navy')
plt.xlabel('Actual', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('Predicted', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)

# Show the plot
plt.tight_layout()

# Print RMSE values
print(f"Test RMSE for k=1: {rmse_k1}")
print(f"Test RMSE for k=3: {rmse_k3}")

y_pred_k1, rmse_k1 = KNN_REGRESSION(1, X_train, y_train, X_test, y_test)
y_pred_k3, rmse_k3 = KNN_REGRESSION(3, X_train, y_train, X_test, y_test)

# Plotting the RMSE values for k=1 and k=3
k_values = [1, 3]
rmse_values = [rmse_k1, rmse_k3]

First_Figure = plt.figure(figsize=(10, 8))

plt.plot(k_values, rmse_values, marker='o', linewidth=3, color='navy')
plt.title('KNN Regressor RMSE for K=1 & K=3', fontsize=14, fontweight='bold', fontstyle='oblique', color='navy')
plt.xlabel('k value', color='blue', fontsize=14, fontweight='bold', labelpad=20)
plt.ylabel('RMSE', color='darkviolet', fontsize=14, fontweight='bold', labelpad=20)
plt.text(0.01, 0.95, "Mariam Hamad - 1200837 \nLeena Affouri - 1200335", transform=plt.gcf().transFigure, fontsize=12,
         fontstyle='oblique', fontweight='bold', color='#0047AB')
# Adding text boxes for x and y values
for (i, j) in zip(k_values, rmse_values):
    plt.text(i, j, f'({i}, {j:.2f})', ha='center', va='bottom',
             bbox=dict(boxstyle="round,pad=0.3", fc="yellow", ec="black", lw=1))

plt.xticks(k_values)
plt.grid(True)

# _________________________________________________________
print("\n\n------------------------------------\n")
print("             THIRD TASK      \n")
print("------------------------------------\n")

X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.4, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)
# Parameter grids
Grid_RF_Parameters = {
    'n_estimators': [10, 50, 100, 200],
    'max_depth': [None, 10, 20, 30],
}
Grid_GB_Parameters = {
    'n_estimators': [10, 50, 100, 200],
    'learning_rate': [0.01, 0.1, 0.2, 0.3],
    'max_depth': [3, 4, 5, 6],
}

# Create the models
rf = RandomForestRegressor(random_state=42)
gb = GradientBoostingRegressor(random_state=42)

# Setup the grid searches
grid_search_rf = GridSearchCV(estimator=rf, param_grid=Grid_RF_Parameters, cv=5, scoring='neg_mean_squared_error',
                              return_train_score=True)
grid_search_gb = GridSearchCV(estimator=gb, param_grid=Grid_GB_Parameters, cv=5, scoring='neg_mean_squared_error',
                              return_train_score=True)

# Perform grid search for Random Forest
grid_search_rf.fit(X_train, y_train)

# Extract the RMSEs and corresponding parameter sets
mean_test_scores = grid_search_rf.cv_results_['mean_test_score']
params = grid_search_rf.cv_results_['params']
rmse_scores = np.sqrt(-mean_test_scores)

# Find the best RMSE and corresponding parameter sets
min_rmse = np.min(rmse_scores)
best_params_indices = np.where(rmse_scores == min_rmse)[0]
best_params_sets = [params[i] for i in best_params_indices]

# Evaluate the best models on the validation set
print("\nEvaluating models with the following best parameters on the validation set:")
for param_set in best_params_sets:
    model = RandomForestRegressor(random_state=42, **param_set)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_val)
    rmse = np.sqrt(mean_squared_error(y_val, y_pred))
    print(f'Parameters: {param_set}, Validation RMSE: {rmse:.5f}')
    best_rmse_grid_search = np.sqrt(-grid_search_rf.best_score_)
    print(f'\nBest RMSE from grid search on testing: {best_rmse_grid_search:.5f}')
# Access the results

cv_results_rf = grid_search_rf.cv_results_

# Print RMSE for all parameter sets
print("Grid Search Results for Random Forest:")
for mean_squared_error_val, params in zip(cv_results_rf['mean_test_score'], cv_results_rf['params']):
    rmse = np.sqrt(-mean_squared_error_val)
    print(f"RMSE: {rmse:.5f} for parameters: {params}")

# Extract RMSE and parameters, then sort by RMSE
sorted_results = sorted([(np.sqrt(-score), params)
                         for score, params in zip(cv_results_rf['mean_test_score'], cv_results_rf['params'])],
                        key=lambda x: x[0])

# Find the top two best unique RMSEs
unique_rmses = sorted(list(set([result[0] for result in sorted_results])))

# Check if there are at least two unique RMSE values
if len(unique_rmses) >= 2:
    best_rmse = unique_rmses[0]
    second_best_rmse = unique_rmses[1]

    # Find all parameter sets with these RMSEs
    best_params = [params for rmse, params in sorted_results if rmse == best_rmse]
    second_best_params = [params for rmse, params in sorted_results if rmse == second_best_rmse]

    print("\nBest parameters with the lowest RMSE:")
    for params in best_params:
        print(params)


else:
    print("There is only one unique RMSE value in the results.")
# Extracting data from cv_results
param_grid = Grid_RF_Parameters  # The parameter grid for Random Forest
scores_matrix = pd.DataFrame(index=param_grid['max_depth'], columns=param_grid['n_estimators'])

for result, params in zip(cv_results_rf['mean_test_score'], cv_results_rf['params']):
    n_estimator = params['n_estimators']
    max_depth = params['max_depth'] if params['max_depth'] is not None else 'None'
    rmse = np.sqrt(-result)
    scores_matrix.at[max_depth, n_estimator] = rmse

# Convert the 'None' max_depth to a numeric value for plotting purposes
scores_matrix.index = scores_matrix.index.fillna('None')

# Plotting the heatmap
plt.figure(figsize=(12, 6))
sns.heatmap(scores_matrix.astype(float), annot=True, fmt=".5f", cmap='viridis')
plt.title('RMSE for different combinations of n_estimators and max_depth in Random Forest', fontsize=14,
          fontweight='bold', fontstyle='oblique', color='navy')
plt.xlabel('Number of Estimators', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('Max Depth (None for unlimited)', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.text(0.01, 0.95, "Mariam Hamad - 1200837 \nLeena Affouri - 1200335", transform=plt.gcf().transFigure, fontsize=12,
         fontstyle='oblique', fontweight='bold', color='#0047AB')

# Access the results
cv_results_rf = grid_search_rf.cv_results_
rmse_values_rf = np.sqrt(-np.array(cv_results_rf['mean_test_score']))
param_combinations_rf = cv_results_rf['params']

plt.figure(figsize=(12, 8))
plt.plot(range(len(rmse_values_rf)), rmse_values_rf, marker='*', linestyle='-', color='purple', linewidth=2,
         markersize=10)

plt.xlabel('Parameter Combinations', color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('Validation RMSE', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.title('Validation RMSE for Random Forest with Different Parameter Combinations', fontsize=14, fontweight='bold',
          fontstyle='oblique', color='navy')
plt.text(0.01, 0.95, "Mariam Hamad - 1200837 \nLeena Affouri - 1200335", transform=plt.gcf().transFigure, fontsize=12,
         fontstyle='oblique', fontweight='bold', color='#0047AB')
plt.xticks(range(len(param_combinations_rf)), [str(params) for params in param_combinations_rf], rotation=90)
plt.grid(True)
plt.tight_layout()

print("_____________________\n")

# ----------------------------------------------------------------------------------------------------
print("\n By Use The Gradient Boosting\n")

# Perform grid search for Gradient Boosting
grid_search_gb.fit(X_train, y_train)

print("Best parameters for Gradient Boosting:", grid_search_gb.best_params_)
gb_best = grid_search_gb.best_estimator_

# Evaluate on the validation set
y_pred_gb = gb_best.predict(X_val)
rmse_gb = np.sqrt(mean_squared_error(y_val, y_pred_gb))
print(f'Validation RMSE for Gradient Boosting: {rmse_gb:.5f}')

best_rmse_grid_search = np.sqrt(-grid_search_gb.best_score_)
print(f'\nBest RMSE from grid search on testing: {best_rmse_grid_search:.5f}')

# Access the results for Gradient Boosting
print("Grid Search Results for Gradient Boosting:")
cv_results_gb = grid_search_gb.cv_results_
for mean_squared_error_val, params in zip(cv_results_gb['mean_test_score'], cv_results_gb['params']):
    rmse = np.sqrt(-mean_squared_error_val)
    print(f"RMSE: {rmse:.5f} for parameters: {params}")

cv_results_gb = grid_search_gb.cv_results_
rmse_values_gb = np.sqrt(-np.array(cv_results_gb['mean_test_score']))
param_combinations_gb = cv_results_gb['params']
rmse_normalized = (rmse_values_gb - np.min(rmse_values_gb)) / (np.max(rmse_values_gb) - np.min(rmse_values_gb))

# Choose a colormap
colormap = plt.cm.viridis

# Apply colormap to normalized RMSE values
colors = colormap(rmse_normalized)

# Scale marker sizes by RMSE (optional: adjust the scaling factor to your preference)
sizes = rmse_normalized * 100  # Scale factor to adjust the marker size

# Use a larger figure size to accommodate the tick labels
plt.figure(figsize=(20, 10))  # Increase the width and height as needed

# Scatter plot to allow variable colors and sizes
plt.scatter(range(len(rmse_values_gb)), rmse_values_gb, marker='*', c=colors, s=sizes, linewidth=2)

# Set label properties
plt.xlabel('Parameter Combinations', color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel('Validation RMSE', color='blue', fontsize=12, fontweight='bold', labelpad=20)

plt.title('Validation RMSE for Gradient Boosting with Different Parameter Combinations', fontsize=16, fontweight='bold',
          fontstyle='oblique', color='navy')

# Adjust the x-axis tick labels
plt.xticks(range(len(param_combinations_gb)), [str(params) for params in param_combinations_gb], rotation=90,
           fontsize=8)  # Decrease fontsize as needed

# Other plot settings
plt.grid(True)
plt.tight_layout()  # This will adjust the plotting area to make sure everything fits without overlapping

print("------------------------------------\n")
print("             FOURTH TASK      \n")
print("------------------------------------\n")

# Training the models on the training set
rf.fit(X_train, y_train)
gb.fit(X_train, y_train)

# Predicting on the test set
y_pred_rf = rf.predict(X_test)
y_pred_gb = gb.predict(X_test)

# Calculating RMSE for both models
rmse_rf_generic = np.sqrt(mean_squared_error(y_test, y_pred_rf))
rmse_gb_generic = np.sqrt(mean_squared_error(y_test, y_pred_gb))

# Printing the RMSE values
print(f"RMSE for Random Forest: {rmse_rf_generic}")
print(f"RMSE for Gradient Boosting: {rmse_gb_generic}")

y_pred_rf = np.random.normal(loc=y_test.mean(), scale=5, size=len(y_test))  # Mock predictions
y_pred_gb = np.random.normal(loc=y_test.mean(), scale=5, size=len(y_test))  # Mock predictions

# Calculate the residuals
residuals_rf = y_test - y_pred_rf
residuals_gb = y_test - y_pred_gb

# Plotting the residuals
plt.figure(figsize=(12, 6))

# Plot for Random Forest
plt.subplot(1, 2, 1)
sns.scatterplot(x=y_pred_rf, y=residuals_rf)
plt.title("Residuals vs Predictions for Random Forest", fontsize=14, fontweight='bold', fontstyle='oblique',
          color='navy', pad=20)
plt.xlabel("Predicted Values", color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel("Residuals", color='blue', fontsize=12, fontweight='bold', labelpad=20)

# Plot for Gradient Boosting
plt.subplot(1, 2, 2)
sns.scatterplot(x=y_pred_gb, y=residuals_gb)
plt.title("Residuals vs Predictions for Gradient Boosting", fontsize=14, fontweight='bold', fontstyle='oblique',
          color='navy', pad=20)
plt.xlabel("Predicted Values", color='darkviolet', fontsize=12, fontweight='bold', labelpad=20)
plt.ylabel("Residuals", color='blue', fontsize=12, fontweight='bold', labelpad=20)
plt.tight_layout()
plt.show()
plt.show()

